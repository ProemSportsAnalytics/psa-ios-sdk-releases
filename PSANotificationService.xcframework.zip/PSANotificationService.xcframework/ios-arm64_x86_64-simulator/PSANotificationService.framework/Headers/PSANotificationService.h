#import <Foundation/Foundation.h>
FOUNDATION_EXPORT double PSANotificationServiceVersionNumber;
FOUNDATION_EXPORT const unsigned char PSANotificationServiceVersionString[];
