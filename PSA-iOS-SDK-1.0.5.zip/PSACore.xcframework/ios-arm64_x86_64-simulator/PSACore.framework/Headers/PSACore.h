#import <Foundation/Foundation.h>
FOUNDATION_EXPORT double PSACoreVersionNumber;
FOUNDATION_EXPORT const unsigned char PSACoreVersionString[];
