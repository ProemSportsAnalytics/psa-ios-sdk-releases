#import <Foundation/Foundation.h>
FOUNDATION_EXPORT double PSAMessagingVersionNumber;
FOUNDATION_EXPORT const unsigned char PSAMessagingVersionString[];
